from django.apps import AppConfig

class JobPortalConfig(AppConfig):
    name = 'JobPortal'