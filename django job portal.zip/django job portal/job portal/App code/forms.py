#this form is the application/apply form for all job seekers

from django.forms import ModelForm
from .models import *


class ApplyForm(models.Model):
    class Meta:
        models=candidates
        field="__all__"