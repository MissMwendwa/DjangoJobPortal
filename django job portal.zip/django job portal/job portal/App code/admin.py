from django.contrib import admin
from .models import *

#register your models here
admin.site.register(Company)
admin.site.register(candidates)